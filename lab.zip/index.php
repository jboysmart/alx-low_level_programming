
<?php 
  session_start();
  if(isset($_SESSION["type"]) && $_SESSION["type"] == "admin"){
    include_once("inc/header2.php");
  }else{
    include_once("inc/header.php");
  }
 ?>

<!--hero section start-->

<section class="banner p-0 pos-r fullscreen-banner">
  <div class="banner-slider owl-carousel no-pb" data-dots="false" data-nav="true">
    <div class="item hero-overlay" data-bg-img="images/bg/01.jpg" data-overlay="6">
      <div class="align-center pt-0">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-10 col-12">
              <h1 class="mb-4 text-black">Research & Verify <span class="text-theme">Laboratory</span> for Testing</h1>
              <p class="lead font-w-5 text-black">Labortech is modern laboratory services Delivering newer flows by their place website is the first impression.</p>
              <div class="btn-box mt-5">
                <a class="btn btn-theme" href="#"> <span>More About</span>
                </a>
                <a class="btn btn-dark" href="appointment.php"> <span>Book Appointment</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="item hero-overlay" data-bg-img="images/bg/02.jpg" data-overlay="6">
      <div class="align-center pt-0">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 col-md-10 col-12">
              <h1 class="mb-4 text-black">Research & Verify <span class="text-theme">Laboratory</span> for Testing</h1>
              <p class="lead font-w-5 text-black">Labortech is modern laboratory services Delivering newer flows by their place website is the first impression.</p>
              <div class="btn-box mt-5">
                <a class="btn btn-theme" href="@"> <span>More About</span>
                </a>
                <a class="btn btn-dark" href="appointment.php"> <span>Book Appointment</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--hero section end-->


<!--body content start-->

<div class="page-content">

<!--feature start-->

<section class="pb-0">
  <div class="container">
    <div class="row">
      <div class="col-lg-3 col-sm-6">
        <div class="featured-item style-1">
          <div class="featured-icon"> <i class="flaticon-laboratory-1"></i>
          </div>
          <div class="featured-title">
            <h5>HIV/AIDS</h5>
          </div>
          <div class="featured-desc">
            <p>Our firm is expert to create an efficient user interface that.</p>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-sm-6 mt-5 mt-sm-0">
        <div class="featured-item style-1 active">
          <div class="featured-icon"> <i class="flaticon-laboratory"></i>
          </div>
          <div class="featured-title">
            <h5>DIARRHEA</h5>
          </div>
          <div class="featured-desc">
            <p>Our firm is expert to create an efficient user interface that.</p>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-sm-6 mt-5 mt-lg-0">
        <div class="featured-item style-1">
          <div class="featured-icon"> <i class="flaticon-biology-1"></i>
          </div>
          <div class="featured-title">
            <h5>TUBERCULOSIS</h5>
          </div>
          <div class="featured-desc">
            <p>Our firm is expert to create an efficient user interface that.</p>
          </div>
        </div>
      </div>
      <div class="col-lg-3 col-sm-6 mt-5 mt-lg-0">
        <div class="featured-item style-1">
          <div class="featured-icon"> <i class="flaticon-help-call"></i>
          </div>
          <div class="featured-title">
            <h5>MALARIA</h5>
          </div>
          <div class="featured-desc">
            <p>Our firm is expert to create an efficient user interface that.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--feature end-->


<!--about start-->

<section>
  <div class="container">
    <div class="row align-items-center justify-content-between">
      <div class="col-lg-5 col-12 order-lg-1">
        <img class="img-fluid" src="images/about/01.jpg" alt="">
      </div>
      <div class="col-lg-7 col-12 mt-6 mt-lg-0">
        <div class="row align-items-end">
          <div class="col-md-7">
            <div class="section-title">
              <h2 class="title">We Employ Latest Research Technology & Company</h2> 
              <p class="text-black font-w-5 mb-3">Weâ€™re here to care for you and your entire family doctor will general health!</p>
              <p>Our doctors include highly qualified male and female practitioners who come from a range of backgrounds and bring a diversity of skills.</p>
            </div>
            <a class="btn btn-theme" href="about-us.html"> <span>More About</span>
            </a>
          </div>
          <div class="col-md-5 mt-6 mt-md-0">
            <p class="mb-4">Our administration and support staff all have exceptional people skills around the world.</p>
            <img class="img-fluid" src="images/sign.png" alt="">
            <ul class="list-unstyled list-icon mt-4">
              <li class="mb-3"><i class="las la-check"></i> Home medicine review</li>
              <li class="mb-3"><i class="las la-check"></i> Highest Quality Results</li>
              <li><i class="las la-check"></i> We Ensure Safe Diagnosis</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--about end-->


<!--service start-->

<section class="position-relative light-bg">
  <div class="container z-index-1">
    <div class="row justify-content-center text-center">
      <div class="col-lg-7 col-12">
        <div class="section-title mb-3">
          <h2 class="title mb-0">We Provide All Aspects Of Medical Practice For Your Whole Family!</h2> 
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col">
        <div class="owl-carousel" data-items="3" data-md-items="2" data-sm-items="1" data-xs-items="1" data-margin="30">
          <div class="item">
            <div class="service-item style-1">
              <div class="service-img mx-4 z-index-1 overflow-hidden">
                <img class="img-fluid" src="images/services/01.jpg" alt="">
                <div class="service-icon"> <i class="flaticon-biology-1"></i>
                </div>
              </div>
              <div class="service-desc white-bg mt-n5 pt-7">
                <div class="service-title">
                  <h4>Biochemistry Solution</h4>
                </div>
                <p>We have put protocols to protect our patients and staff care.</p> <a class="link-btn" href="biochemistry-solution.html"><i class="las la-long-arrow-alt-right"></i></a>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="service-item style-1 active">
              <div class="service-img mx-4 z-index-1 overflow-hidden">
                <img class="img-fluid" src="images/services/02.jpg" alt="">
                <div class="service-icon"> <i class="flaticon-research"></i>
                </div>
              </div>
              <div class="service-desc white-bg mt-n5 pt-7">
                <div class="service-title">
                  <h4>Pharmaceutical Research</h4>
                </div>
                <p>We have put protocols to protect our patients and staff care.</p> <a class="link-btn" href="pharmaceutical-research.html"><i class="las la-long-arrow-alt-right"></i></a>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="service-item style-1">
              <div class="service-img mx-4 z-index-1 overflow-hidden">
                <img class="img-fluid" src="images/services/03.jpg" alt="">
                <div class="service-icon"> <i class="flaticon-test"></i>
                </div>
              </div>
              <div class="service-desc white-bg mt-n5 pt-7">
                <div class="service-title">
                  <h4>Pathologycam Testing</h4>
                </div>
                <p>We have put protocols to protect our patients and staff care.</p> <a class="link-btn" href="pathologycam-testing.html"><i class="las la-long-arrow-alt-right"></i></a>
              </div>
            </div>
          </div>
          <div class="item">
            <div class="service-item style-1">
              <div class="service-img mx-4 z-index-1 overflow-hidden">
                <img class="img-fluid" src="images/services/04.jpg" alt="">
                <div class="service-icon"> <i class="flaticon-research"></i>
                </div>
              </div>
              <div class="service-desc white-bg mt-n5 pt-7">
                <div class="service-title">
                  <h4>Chemical Research</h4>
                </div>
                <p>We have put protocols to protect our patients and staff care.</p> <a class="link-btn" href="chemical-research.html"><i class="las la-long-arrow-alt-right"></i></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="shape-1 overflow-hidden bottom">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320">
      <path fill="#ffffff" fill-opacity="1" d="M0,96L21.8,112C43.6,128,87,160,131,154.7C174.5,149,218,107,262,90.7C305.5,75,349,85,393,122.7C436.4,160,480,224,524,234.7C567.3,245,611,203,655,165.3C698.2,128,742,96,785,85.3C829.1,75,873,85,916,117.3C960,149,1004,203,1047,229.3C1090.9,256,1135,256,1178,234.7C1221.8,213,1265,171,1309,154.7C1352.7,139,1396,149,1418,154.7L1440,160L1440,320L1418.2,320C1396.4,320,1353,320,1309,320C1265.5,320,1222,320,1178,320C1134.5,320,1091,320,1047,320C1003.6,320,960,320,916,320C872.7,320,829,320,785,320C741.8,320,698,320,655,320C610.9,320,567,320,524,320C480,320,436,320,393,320C349.1,320,305,320,262,320C218.2,320,175,320,131,320C87.3,320,44,320,22,320L0,320Z"></path>
    </svg>
  </div>
</section>

<!--service end-->











</div>

<!--body content end--> 


<?php include_once("inc/footer.php"); ?>


</div>

<!-- page wrapper end -->


<!-- Cart Modal -->
<div class="modal fade cart-modal" id="cartModal" tabindex="-1" role="dialog" aria-labelledby="ModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ModalLabel">Your Cart (2)</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div>
          <div class="row align-items-center">
            <div class="col-5 d-flex align-items-center">
              <div class="me-4">
                <button type="submit" class="btn btn-theme btn-sm"><i class="las la-times"></i>
                </button>
              </div>
              <!-- Image -->
              <a href="product-left-image.html">
                <img class="img-fluid" src="images/product/01.jpg" alt="...">
              </a>
            </div>
            <div class="col-7">
              <!-- Title -->
              <h6><a class="link-title" href="product-single.html">Dealistic Microscope</a></h6>
              <div class="product-meta"><span class="me-2 text-theme">$120.00</span><span class="text-muted">x 1</span>
              </div>
            </div>
          </div>
        </div>
        <hr class="my-5">
        <div>
          <div class="row align-items-center">
            <div class="col-5 d-flex align-items-center">
              <div class="me-4">
                <button type="submit" class="btn btn-theme btn-sm"><i class="las la-times"></i>
                </button>
              </div>
              <!-- Image -->
              <a href="product-single.html">
                <img class="img-fluid" src="images/product/02.jpg" alt="...">
              </a>
            </div>
            <div class="col-7">
              <!-- Title -->
              <h6><a class="link-title" href="product-left-image.html">Biotechnology Microscope</a></h6>
              <div class="product-meta"><span class="me-2 text-theme">$160.00</span><span class="text-muted">x 1</span>
              </div>
            </div>
          </div>
        </div>
        <hr class="my-5">
        <div class="d-flex justify-content-between align-items-center mb-8"> <span class="text-muted">Subtotal:</span>  <span class="text-dark">$280.00</span> 
        </div> <a href="product-cart.html" class="btn btn-theme me-2">View Cart</a>
        <a href="product-checkout.html" class="btn btn-dark">Continue To Checkout</a>
      </div>
    </div>
  </div>
</div>



<!--back-to-top start-->

<div class="scroll-top"><a class="smoothscroll" href="#top"><i class="las la-location-arrow"></i></a></div>

<!--back-to-top end-->

 
<!-- inject js start -->

<!--== jquery -->
<script src="js/theme.js"></script>

<!--== theme-plugin -->
<script src="js/theme-plugin.js"></script>

<!--== color-customize -->
<script src="js/color-customize/color-customizer.js"></script> 

<!--== theme-script -->
<script src="js/theme-script.js"></script>

<!-- inject js end -->

</body>

</html>