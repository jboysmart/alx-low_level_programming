
<?php 
  session_start();
   include_once("inc/header.php"); 
   require_once("./inc/connect.php");
   ?>


<!--page title start-->

<section class="page-title parallaxie" data-bg-img="images/bg/06.jpg">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="white-bg p-2 d-inline-block">
        <h3 class="text-theme">Lis of boo<span class="text-black">ked Appointment</span></h3>
        </div>
      </div>
    </div>
  </div>
</section>

<!--page title end-->


<!--body content start-->

<div class="page-content">

<!--product list start-->

<section>
  <div class="container">
    <div class="row">
      <div class="col-lg-9 col-md-12 order-lg-12">
        <div class="row mb-4 align-items-center">
          <div class="col-md-10 mb-3 mb-md-0"> <h3 class="text-muted"> Showing the list of appointment made</h3>
          </div>
        </div>
        <?php
        $username = $_SESSION["user"];
          $check = $conn->query("SELECT * FROM appointment_tb WHERE patient='{$username}' order by date");
          if(mysqli_num_rows($check) > 0){
            while($row = $check->fetch_array(MYSQLI_BOTH)){

            ?>
            <div class="card product-card rounded-0 product-list mb-5">
              <div class="row align-items-center">
                <div class="col-lg-12 col-md-7">
                  <div class="card-body" style="background:#FFEEC2;">
                    <div class="product-title"><a href="product-single.html"><?php echo strtoupper($row["test"]); ?> TEST</a>
                    </div>
                    <div class="mt-1"> 
                          <span class="product-price"><b class="text-muted">Test Cost: </b> &nbsp; &nbsp; <b>N</b> 4, 000.00</span>
                          &nbsp; &nbsp;<span class="product-price"> <b class="text-muted">Time: </b> <?php echo ucfirst($row["time"]); ?></span>
                          &nbsp; &nbsp;<span class="product-price"> <b class="text-muted">Date: </b> <?php echo strtoupper($row["date"]); ?></span>
                          &nbsp; &nbsp;<span class="product-price"> <b class="text-muted">Appointment Status: </b> <?php echo strlen(trim($row["status"])) > 2? $row["status"]:"Not Approved Yet"; ?></span>
                    </div>
                    <p class="mb-0 mt-2">
                    </div>
                </div>
              </div>
            </div>
            <?php
            }
            
          }else{ 
            ?>
            <div class="card product-card rounded-0 product-list mb-5">
          <div class="row align-items-center">
            <div class="col-lg-4 col-md-5">
              <div class="product-img position-relative overflow-hidden">
                <img class="img-fluid" src="images/product/01.jpg" alt="...">
                <div class="product-link position-absolute">
                  <button class="btn-compare mb-3" type="button"><i class="las la-random"></i> 
                  </button>
                </div>
              </div>
            </div>
            <div class="col-lg-8 col-md-7">
              <div class="card-body">
                <div class="product-title"><a href="product-single.html">No booked appointment yet</a>
                </div>
                <div class="mt-1"> <span class="product-price"><del class="text-muted">$140.00</del> $120.00</span>
                </div>
                <p class="mb-0 mt-2">Curabitur semper varius lectus sed consequat. Nam accumsan dapibus sem, sed lobortis nisi porta vitae. Ut quam tortor, facilisis nec laoreet consequat, malesuada a massa. Proin pretium tristique leo et imperdiet.</p>
              </div>
            </div>
          </div>
        </div>
            <?php

           }


        ?>
        <!-- <nav aria-label="Page navigation" class="mt-6">
          <ul class="pagination">
            <li class="page-item"><a class="page-link" href="#">Previous</a>
            </li>
            <li class="page-item"><a class="page-link" href="#">1</a>
            </li>
            <li class="page-item"><a class="page-link" href="#">2</a>
            </li>
            <li class="page-item"><a class="page-link" href="#">3</a>
            </li>
            <li class="page-item"><a class="page-link" href="#">Next</a>
            </li>
          </ul>
        </nav> -->
      </div>
      <div class="col-lg-3 col-md-12 sidebar mt-6 mt-lg-0 order-lg-1">
        <div class="widget product-categories widget-categories mb-4 p-4 border">
          <h4 class="widget-title mb-3">Categories</h4>
          <ul class="list-unstyled list-group list-group-flush">
            <li class="mb-3"> <a class="text-black border-0" href="#">
                  Tuberculosis
                  <span class="ms-1">(12)</span>
                </a>
            </li>
            <li class="mb-3"> <a class="text-black border-0" href="#">
                  HIV/Aids
                  <span class="ms-1">(15)</span>
                </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</section>

<!--product list end-->

</div>

<!--body content end--> 



<?php include_once("inc/footer.php"); ?>


</div>

<!-- page wrapper end -->



<!--back-to-top start-->

<div class="scroll-top"><a class="smoothscroll" href="#top"><i class="las la-location-arrow"></i></a></div>

<!--back-to-top end-->

 
<!-- inject js start -->

<!--== jquery -->
<script src="js/theme.js"></script>

<!--== theme-plugin -->
<script src="js/theme-plugin.js"></script>

<!--== color-customize -->
<script src="js/color-customize/color-customizer.js"></script> 

<!--== theme-script -->
<script src="js/theme-script.js"></script>

<!-- inject js end -->

</body>

</html>