
<?php 
  session_start();
   include_once("inc/header2.php"); 
   require_once("./inc/connect.php");

   if(isset($_GET["reject"])){
     if($conn->query("UPDATE appointment_tb SET status='Reject' WHERE id='{$_GET["reject"]}'")){
      
     }else{
       echo"<script> alert('A problem was encountered!'); </script>";
     }


   }

   if(isset($_GET["accept"])){
    if($conn->query("UPDATE appointment_tb SET status='Accept' WHERE id='{$_GET["accept"]}'")){

    }else{
      echo"<script> alert('A problem was encountered!'); </script>";
    }

  }
   ?>


<!--page title start-->

<section class="page-title parallaxie" data-bg-img="images/bg/06.jpg">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="white-bg p-2 d-inline-block">
        <h3 class="text-theme">Lis of boo<span class="text-black">ked Appointment</span></h3>
        </div>
      </div>
    </div>
  </div>
</section>

<!--page title end-->


<!--body content start-->

<div class="page-content">

<!--product list start-->

<section>
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 order-lg-12">
        <div class="row mb-4 align-items-center">
          <div class="col-md-10 mb-3 mb-md-0"> <h4 class="text-muted"> Showing the list of submitted appointment</h4>
          </div>
        </div>
        <?php
        $username = $_SESSION["user"];
          $check = $conn->query("SELECT * FROM patient_tb order by date desc");
        ?>
            <table class="table">
              <thead class="thead-dark">
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Patient Name</th>
                  <th scope="col">Phone number</th>
                  <th scope="col">Email</th>
                  <th scope="col">Gender</th>
                  <th scope="col">Status</th>
                </tr>
              </thead>
              <tbody>
              <?php
              $counta = 0;
                if(mysqli_num_rows($check) > 0){
                while($row = $check->fetch_array(MYSQLI_BOTH)){

                ?>
                <tr>
                  <th scope="row">1</th>
                  <td><?php echo $row["fname"]." ".$row["lname"]; ?></td>
                  <td><?php echo $row["phone"];  ?></td>
                  <td><?php echo ucfirst($row["email"]);  ?> Section</td>
                  <td><?php echo $row["gender"]; ?></td>
                  <style>
                    .label-danger{ background:red; color:white; padding:6px 12px;}
                  </style>
                  <td>
                    <a href="viewpatient.php?reject=<?php echo $row["id"]; ?>" class="label label-danger">Delete Patient</a>
                  </td>
                </tr>
                <?php
                }
              }else{

              }
                ?>

              </tbody>
            </table>
           
        <!-- <nav aria-label="Page navigation" class="mt-6">
          <ul class="pagination">
            <li class="page-item"><a class="page-link" href="#">Previous</a>
            </li>
            <li class="page-item"><a class="page-link" href="#">1</a>
            </li>
            <li class="page-item"><a class="page-link" href="#">2</a>
            </li>
            <li class="page-item"><a class="page-link" href="#">3</a>
            </li>
            <li class="page-item"><a class="page-link" href="#">Next</a>
            </li>
          </ul>
        </nav> -->
      </div>
    </div>
  </div>
</section>

<!--product list end-->

</div>

<!--body content end--> 



<?php include_once("inc/footer.php"); ?>


</div>

<!-- page wrapper end -->



<!--back-to-top start-->

<div class="scroll-top"><a class="smoothscroll" href="#top"><i class="las la-location-arrow"></i></a></div>

<!--back-to-top end-->

 
<!-- inject js start -->

<!--== jquery -->
<script src="js/theme.js"></script>

<!--== theme-plugin -->
<script src="js/theme-plugin.js"></script>

<!--== color-customize -->
<script src="js/color-customize/color-customizer.js"></script> 

<!--== theme-script -->
<script src="js/theme-script.js"></script>

<!-- inject js end -->

</body>

</html>