<?php 
  session_start();
   include_once("inc/header.php");
   require_once("./inc/connect.php");
  ?>
<!--page title start-->
<?php
  if(isset($_POST["btnAppointment"])){
    if(isset($_POST["date"]) && strlen($_POST["date"]) > 4){
          $test = trim($conn->real_escape_string($_POST["test"]));
          $time = ucfirst($conn->real_escape_string($_POST["time"]));
          $date = trim($conn->real_escape_string($_POST["date"]));
          $message = trim($conn->real_escape_string($_POST["message"]));
          $username = $_SESSION["user"];
  
          $check = $conn->query("SELECT id FROM appointment_tb WHERE patient='{$username}' AND date='{$date}'");
              if(mysqli_num_rows($check) == 0){
                if($conn->query("INSERT INTO appointment_tb(patient,test,time,date,message) VALUES('{$username}','{$test}','{$time}','{$date}','{$message}')")){
                  echo"<script> alert('Appointment has been booked succesfully!'); </script>";
                }else{ echo "<script> alert('An error was encountered during submission!!'); </script>";}
              }else{ echo"<script> alert('This appointment has been booked by you!'); </script>"; }
  
    }else{ echo "<script> alert('Sorry!, A date is highly required.'); </script>";}

  }
  
?>

<section class="page-title parallaxie" data-bg-img="images/bg/06.jpg">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="white-bg p-1 d-inline-block">
        <h3 class="text-theme">Book <span class="text-black">Appointment</span></h3>
        
        </div>
      </div>
    </div>
  </div>
</section>

<!--page title end-->


<!--body content start-->

<div class="page-content">

<!--contact start-->

<section>
  <div class="container">
    <div class="row">
      <div class="col">
        <div class="light-bg">
          <div class="row text-center">
            <div class="col-lg-12 ps-lg-0">
              <div class="white-bg px-3 py-5 p-md-6 shadow-sm">
                <form class="row" method="post">
                  <div id="formmessage"></div>
                  <style>
                    label{ display:block; text-align:left; padding-left:6px; font-size:16px;}
                  </style>
                  <div class="form-group col-md-6">
                    <label for="">Select Test</label>
                    <select name="test" class="form-select form-control">
                      <option value="Tuberculosis">Tuberculosis Test</option>
                      <option value="Diabetes">Diabetes Test</option>
                    </select>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="">Appointment Date</label>
                    <input type="date" name="date" class="form-control" required="required">
                   
                  </div>
                  <div class="form-group col-md-6">
                    <label for="">Select Time</label>
                    <select name="time" class="form-select form-control">
                      <option value="morning">Morning Section</option>
                      <option value="afternoon">Afternoon Section</option>
                      <option value="evening">Evening Section</option>
                    </select>
                  </div>
                  <div class="form-group col-md-6">
                    <label for="">Message (<small>Optional</small>) </label>
                    <input type="text" name="message" class="form-control" placeholder="Send a message if any!">
                   
                  </div>
                  <div class="col-md-12 text-center mt-4">
                    <button class="btn btn-theme" type="submit" name="btnAppointment"><span>Book Appointment Now</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--contact end-->



</div>

<!--body content end--> 

<?php include_once("inc/footer.php"); ?>


<!--back-to-top start-->

<div class="scroll-top"><a class="smoothscroll" href="#top"><i class="las la-location-arrow"></i></a></div>

<!--back-to-top end-->

 
<!-- inject js start -->

<!--== jquery -->
<script src="js/theme.js"></script>

<!--== theme-plugin -->
<script src="js/theme-plugin.js"></script>

<!--== color-customize -->
<script src="js/color-customize/color-customizer.js"></script> 

<!--== theme-script -->
<script src="js/theme-script.js"></script>

<!-- inject js end -->

</body>

</html>