<?php include_once("inc/header.php");
    require_once("./inc/connect.php");

?>
<!--page title start-->
<?php
  if(isset($_POST["btnreg"])){
    if(isset($_POST["email"]) && strlen($_POST["email"]) > 4){
      if(isset($_POST["password"]) && strlen($_POST["password"]) > 4){
          $fname = trim($conn->real_escape_string($_POST["fname"]));
          $lname = trim($conn->real_escape_string($_POST["lname"]));
          $phone = trim($conn->real_escape_string($_POST["phone"]));
          $gender = trim($conn->real_escape_string($_POST["gender"]));
          $email = trim($conn->real_escape_string($_POST["email"]));
          $password = strtolower($_POST["password"]);
  
          $check = $conn->query("SELECT id FROM patient_tb WHERE email='{$email}'");
              if(mysqli_num_rows($check) == 0){
                if($conn->query("INSERT INTO patient_tb(fname,lname,email,phone,gender,password) VALUES('{$fname}','{$lname}','{$email}','{$phone}','{$gender}','{$password}')")){
                  echo"<script> alert('Patient registration was successful!'); </script>";
                }else{ echo "<script> alert('An error was encountered during submission!!'); </script>";}
              }else{ echo"<script> alert('A patient with this email address is existing in our database!'); </script>"; }
  
      }else{ echo "<script> alert('Sorry!, Password input length must be above 5.'); </script>";}
    }else{ echo "<script> alert('Sorry!, Email input length must be above 5.'); </script>";}

  }
  
?>

<section class="page-title parallaxie" data-bg-img="images/bg/06.jpg">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="white-bg p-1 d-inline-block">
        <h3 class="text-theme">Patients <span class="text-black">Registration</span></h3>
        
        </div>
      </div>
    </div>
  </div>
</section>

<!--page title end-->


<!--body content start-->

<div class="page-content">

<!--contact start-->

<section>
  <div class="container">
    <div class="row">
      <div class="col">
        <div class="light-bg">
          <div class="row text-center">
            <div class="col-lg-12 ps-lg-0">
              <div class="white-bg px-3 py-5 p-md-6 shadow-sm">
                <form class="row" method="post" action="">
                  <div id="formmessage"></div>
                  <div class="form-group col-md-6">
                    <input id="form_name" type="text" name="fname" class="form-control" placeholder="Surname" required>
                  </div>
                  <div class="form-group col-md-6">
                    <input id="form_name" type="text" name="lname" class="form-control" placeholder="Other Name" required>
                  </div>
                  <div class="form-group col-md-6">
                    <input id="form_email" type="email" name="email" class="form-control" placeholder="Email" required>
                  </div>
                  <div class="form-group col-md-6">
                    <input id="form_phone" type="tel" name="phone" class="form-control" placeholder="Phone" required>
                  </div>
                  <div class="form-group col-md-6">
                    <select name="gender" class="form-select form-control" required>
                      <option>- Choose gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Nobe">Can't discuss my gender!</option>
                    </select>
                  </div>
                  <div class="form-group col-md-6">
                    <input id="form_phone" type="password" name="password" class="form-control" placeholder="Password" required>
                  </div>
                  <div class="col-md-12 text-center mt-4">
                    <button class="btn btn-theme" type="submit"  name="btnreg"><span>Submit registration</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--contact end-->



</div>

<!--body content end--> 

<?php include_once("inc/footer.php"); ?>


<!--back-to-top start-->

<div class="scroll-top"><a class="smoothscroll" href="#top"><i class="las la-location-arrow"></i></a></div>

<!--back-to-top end-->

 
<!-- inject js start -->

<!--== jquery -->
<script src="js/theme.js"></script>

<!--== theme-plugin -->
<script src="js/theme-plugin.js"></script>

<!--== color-customize -->
<script src="js/color-customize/color-customizer.js"></script> 

<!--== theme-script -->
<script src="js/theme-script.js"></script>

<!-- inject js end -->

</body>

</html>