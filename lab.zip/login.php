<?php
  require_once("inc/connect.php");
  if(isset($_POST["btnlog"])){
    if(isset($_POST["email"]) && strlen($_POST["email"]) > 4){
      if(isset($_POST["password"]) && strlen($_POST["password"]) > 4){
        $email = trim($conn->real_escape_string($_POST["email"]));
        $password = strtolower($_POST["password"]);
        
        $check = $conn->query("SELECT * FROM patient_tb WHERE email='{$email}' AND password='{$password}'");
        if(mysqli_num_rows($check) == 1){
          session_start();
          $_SESSION["active"] = "ACTIVE";
          $_SESSION["type"] = "patient";
          $_SESSION["user"] = $email;
          header("location: ./");
        }else{ echo" Patient doesn't exist in this lab database!"; }
      }else{ echo "Sorry!, Password input length must be above 5.";}
    }else{ echo "Sorry!, Email input length must be above 10.";}
  }
  
include_once("inc/header.php");
?>


<!--page title start-->

<section class="page-title parallaxie" data-bg-img="images/bg/06.jpg">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="white-bg p-1 d-inline-block">
        <h3 class="text-theme">Pati<span class="text-black">ents</span> Log<span class="text-black">in</span></h3>

      </div>
    </div>
  </div>
</section>

<!--page title end-->


<!--body content start-->

<div class="page-content">

<!--login start-->

<section>
  <div class="container">
    <div class="row">
      <div class="col-lg-6 text-center dark-bg">
        <div class="p-lg-5 px-3 py-5">     
        <img class="img-fluid" src="images/login-img.png" alt="">     
          <div class="section-title mb-0 mt-5">
            <h2 class="title">Welcome To Patients Login Page</h2> 
            <p class="mb-0 text-light">kLab; the best lab ever for treating tuberculosis!</p>
          </div>
          

        </div>
      </div>
      <div class="col-lg-6 white-bg">
        <div class="p-lg-5 px-3 py-5">
          <h3 class="mb-4">Login Your Account</h3> 
          <form method="post" action="">
            <div class="messages"></div>
            <div class="form-group">
              <input id="form_name" type="email" name="email" class="form-control" placeholder="Email" required="required" data-error="Username is required.">
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group">
              <input id="form_password" type="password" name="password" class="form-control" placeholder="Password" required="required" data-error="password is required.">
              <div class="help-block with-errors"></div>
            </div>
            <div class="form-group mt-4 mb-5">
              <div class="remember-checkbox d-flex align-items-center justify-content-between">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="" id="remember" checked>
                  <label class="form-check-label" for="remember">Remember me</label>
                </div> <a href="#">Forgot Password?</a>
              </div>
            </div>
            <button class="btn btn-theme" type="submit"  name="btnlog"><span>Login Now</span>
                    </button>
          </form>
          <div class="d-flex align-items-center mt-4"> <span class="text-black me-1">Don't have an account?</span>
            <a href="register.php">Sign Up</a>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--login end-->

</div>

<!--body content end--> 
 <?php include_once("inc/footer.php"); ?>


</div>

<!-- page wrapper end -->


<!--back-to-top start-->

<div class="scroll-top"><a class="smoothscroll" href="#top"><i class="las la-location-arrow"></i></a></div>

<!--back-to-top end-->

 
<!-- inject js start -->

<!--== jquery -->
<script src="js/theme.js"></script>

<!--== theme-plugin -->
<script src="js/theme-plugin.js"></script>

<!--== color-customize -->
<script src="js/color-customize/color-customizer.js"></script> 

<!--== theme-script -->
<script src="js/theme-script.js"></script>

<!-- inject js end -->

</body>

</html>