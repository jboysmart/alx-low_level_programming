<?php 
   session_start();
   include_once("inc/header2.php"); 
   require_once("./inc/connect.php");
   ?>
<!--page title start-->

<section class="page-title parallaxie" data-bg-img="images/bg/06.jpg">
  <div class="container">
    <div class="row">
      <div class="col-lg-6">
        <div class="white-bg p-1 d-inline-block">
        <h3 class="text-theme">Submit <span class="text-black">Lab Result</span></h3>
        
        </div>
      </div>
    </div>
  </div>
</section>

<!--page title end-->


<!--body content start-->

<div class="page-content">

<!--contact start-->

<section>
  <div class="container">
    <div class="row">
      <div class="col">
        <div class="light-bg">
          <div class="row text-center">
            
            <div class="col-lg-12 ps-lg-0">
              <div class="white-bg px-3 py-5 p-md-6 shadow-sm">
                <form id="contact-form" class="row" method="post" action="php/contact.php">
                  <div id="formmessage"></div>
                  <div class="form-group col-md-6">
                    <input id="form_name" type="text" name="name" class="form-control" placeholder="Name" required="required">
                  </div>
                  <div class="form-group col-md-6">
                    <input id="form_email" type="email" name="email" class="form-control" placeholder="Email" required="required">
                  </div>
                  <div class="form-group col-md-6">
                    <input id="form_phone" type="tel" name="phone" class="form-control" placeholder="Phone" required="required">
                  </div>
                  <div class="form-group col-md-6">
                    <select name="select" class="form-select form-control">
                      <option>- Choose Service</option>
                      <option>Pathology</option>
                      <option>Diabetes</option>
                      <option>Chemical</option>
                    </select>
                  </div>
                  <div class="form-group col-md-12">
                    <textarea id="form_message" name="message" class="form-control" placeholder="Message" rows="3" required="required"></textarea>
                  </div>
                  <div class="col-md-12 text-center mt-4">
                    <button class="btn btn-theme"><span>Send Messages</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!--contact end-->



</div>

<!--body content end--> 

<?php include_once("inc/footer.php"); ?>


<!--back-to-top start-->

<div class="scroll-top"><a class="smoothscroll" href="#top"><i class="las la-location-arrow"></i></a></div>

<!--back-to-top end-->

 
<!-- inject js start -->

<!--== jquery -->
<script src="js/theme.js"></script>

<!--== theme-plugin -->
<script src="js/theme-plugin.js"></script>

<!--== color-customize -->
<script src="js/color-customize/color-customizer.js"></script> 

<!--== theme-script -->
<script src="js/theme-script.js"></script>

<!-- inject js end -->

</body>

</html>