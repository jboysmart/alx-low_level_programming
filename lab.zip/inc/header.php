<?php
  if(isset($_GET["a"])){
    if(isset($_SESSION["active"])){
      if($_SESSION["active"]){
        session_destroy();
        header("Location: ./");
      }
    }
    
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>

<!-- meta tags -->
<meta charset="utf-8">
<meta name="keywords" content="bootstrap 5, premium, multipurpose, sass, scss, saas, rtl, Laboratory, medical" />
<meta name="description" content="Laboratory & Science Research HTML5 Template" />
<meta name="author" content="www.themeht.com" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Title -->
<title>LM Labo</title>

<!-- favicon icon -->
<link rel="shortcut icon" href="images/favicon.ico" />

<!-- inject css start -->

<!--== bootstrap -->
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />

<!--== fonts -->
<link href="https://fonts.googleapis.com/css2?family=Livvic:ital,wght@0,300;0,400;0,500;0,600;0,700;0,900;1,300;1,400;1,500;1,600;1,700;1,900&display=swap" rel="stylesheet"> 

<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet"> 

<!--== animate -->
<link href="css/animate.css" rel="stylesheet" type="text/css" />

<!--== line-awesome -->
<link href="css/line-awesome.min.css" rel="stylesheet" type="text/css" />

<!--== magnific-popup -->
<link href="css/magnific-popup.css" rel="stylesheet" type="text/css" />

<!--== owl.carousel -->
<link href="css/owl.carousel.css" rel="stylesheet" type="text/css" />

<!--== lightslider -->
<link href="css/lightslider.min.css" rel="stylesheet" type="text/css" />

<!--== base -->
<link href="css/base.css" rel="stylesheet" type="text/css" />

<!--== shortcodes -->
<link href="css/shortcodes.css" rel="stylesheet" type="text/css" />

<!--== spacing -->
<link href="css/spacing.css" rel="stylesheet" type="text/css" />

<!--== style -->
<link href="css/style.css" rel="stylesheet" type="text/css" />

<!--== color-customizer -->
<link href="#" data-style="styles" rel="stylesheet">
<link href="css/color-customize/color-customizer.css" rel="stylesheet" type="text/css" />

<!-- inject css end -->

</head>

<body>

<!-- page wrapper start -->

<div class="page-wrapper">

<!-- preloader start -->

<div id="ht-preloader">
  <div class="clear-loader d-flex align-items-center justify-content-center">
    <div class="loader">
     <span class="plus"></span>
    <span class="plus"></span>
    <span class="dot"></span>
    <span class="dot"></span>
    <span class="dot"></span>
    <span class="dot"></span>
    </div>
  </div>
</div>

<!-- preloader end -->


<!--header start-->

<header id="site-header" class="header">
  <div class="header-top light-bg">
    <div class="container-fluid px-lg-8">
      <div class="row">
        <div class="col d-flex align-items-center justify-content-between">
          <div class="topbar-link d-flex align-items-center text-black">
            <div class="d-none d-sm-flex align-items-center me-3">
              <div> <i class="las la-phone"></i>
              </div>
              <div>Emergency Line: <a class="text-black" href="tel:+23457678900"> +234-91-5567-8900</a>
              </div>
            </div>
            <div class="d-none d-md-flex align-items-center me-3">
              <div> <i class="las la-map-marker"></i>
              </div>
              <div>
                <div>Location: Abakaliki, Nigeria</div>
              </div>
            </div>
            <div class="d-none d-lg-flex align-items-center">
              <div> <i class="las la-business-time"></i>
              </div>
              <div>
                <div>Mon-Sat: 9.30am To 7.00pm</div>
              </div>
            </div>
          </div>
          <div class="d-flex align-items-center"> 
            <div class="language-selection ms-3 py-3">
              <div class="dropdown">
                  <?php
                        if(isset($_SESSION["active"])){
                  ?>
                <button class="dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">Users Dashboard Options</button>
                <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                  <?php
                        if(isset($_SESSION["type"])){
                          if($_SESSION["type"] == "patient"){
                  ?>
                  <li><a class="dropdown-item" href="appointment.php">Book Appointment</a>
                  </li>
                  <li><a class="dropdown-item" href="list.php">Appointment History</a>
                  </li>
                  <li><a class="dropdown-item" href="record.php">View Medical Report</a>
                  </li>
                  <li><a href="index.php?a=logout" class="dropdown-item">Logout</a>
                  </li>
                    <?php

                    }
                  
                  } ?>
                        
                </ul>
                <?php } ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id="header-wrap">
    <div class="container-fluid px-lg-8">
      <div class="row">
        <div class="col">
          <nav class="navbar navbar-expand-lg">
            <a class="navbar-brand logo" href="index.html">
              <img id="logo-img" class="img-fluid" src="images/logo.png" alt="">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"> <span></span>
              <span></span>
              <span></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav ms-auto me-auto position-relative">
                <!-- Home -->
                <li class="nav-item"> <a class="nav-link active" href="./">Home</a></li>
                <li class="nav-item"> <a class="nav-link " href="#">About App</a></li>
                <?php
                        if(!isset($_SESSION["active"])){
                  ?>
                <li class="nav-item"> <a class="nav-link " href="adlog.php">Admin Login </a></li>
                <li class="nav-item"> <a class="nav-link " href="login.php">Patient Login </a></li>
                <li class="nav-item"> <a class="nav-link " href="register.php">Patient Registration</a></li>
                <?php } ?>
                <li class="nav-item"> <a class="nav-link " href="contact.php">Contact</a></li>
              </ul>
            </div>
            <div class="right-nav align-items-center d-flex justify-content-end">
                
              <a class="btn btn-theme btn-sm d-none d-md-inline-block"><span>Thanks for coming around.</span></a>
            </div>
          </nav>
        </div>
      </div>
    </div>
  </div>
</header>

<!--header end-->