<?php
    $conn = new mysqli("localhost","root","","lab") or die("Error connecting to database!");
?>