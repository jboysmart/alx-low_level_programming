<!--footer start-->

<footer class="footer light-bg">
  <div class="primary-footer">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12 col-12" style="padding:1.5rem;">
          
          <div class="row">
            <div class="col">
              <div style="text-align:center; padding:1.5rem; width:100%;" class="copyright mt-5">Copyright &copy; 2021 All rights reserved | LabReport Made by <i class="lar la-heart text-theme heartBeat2"></i>              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</footer>

<!--footer end-->